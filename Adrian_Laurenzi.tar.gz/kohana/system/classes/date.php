<?php defined('SYSPATH') or die('No direct script access.');

class Date extends Kohana_Date {}
