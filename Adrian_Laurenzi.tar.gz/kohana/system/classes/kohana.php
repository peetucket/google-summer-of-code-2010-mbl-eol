<?php defined('SYSPATH') or die('No direct script access.');

class Kohana extends Kohana_Core {}
