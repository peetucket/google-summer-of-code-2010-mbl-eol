<?php defined('SYSPATH') or die('No direct script access.');

class Profiler extends Kohana_Profiler {}
