<?php defined('SYSPATH') or die('No direct script access.');

class Route extends Kohana_Route {}
