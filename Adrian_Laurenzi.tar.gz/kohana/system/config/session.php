<?php defined('SYSPATH') or die('No direct script access.');

return array(
	'cookie' => array(
		'encrypted' => FALSE,
	),
);
