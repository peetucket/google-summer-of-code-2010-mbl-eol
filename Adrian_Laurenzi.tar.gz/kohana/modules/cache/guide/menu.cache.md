1. **Kohana Cache**
   - [About](cache.about)
   - [Configuration](cache.config)
   - [Usage](cache.usage)
   - [Examples](cache.examples)