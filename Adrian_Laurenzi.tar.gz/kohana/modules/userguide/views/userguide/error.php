<h1>Kodoc - <?php echo __('Error'); ?></h1>

<p><?php echo $message ?></p>