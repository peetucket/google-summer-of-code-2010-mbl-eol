<?php defined('SYSPATH') or die('No direct script access.');

return array
(
	'User Guide' => '用户手册',

	// Errors
	'Error' => '错误',
	'Userguide page not found' => '用户手册页面无法找到',
	'API Reference: Class not found.' => 'API 参考: 没有找到此类。',
	'That class is hidden' => '那个是隐藏类',

	// API
	'Table of Contents' => '目录',
	'Available Classes' => '可用的类',
	'Class Contents' => '类列表',
	'Constants' => '常量',
	'Properties' => '属性',
	'Methods' => '方法',
	'None' => '无',
	'Parameters' => '参数',
	'Parameter' => '参数',
	'Type' => '类型',
	'Description' => '描述',
	'Default' => '默认',
	'Return Values' => '返回值',
	'Source Code' => '源代码',
);
