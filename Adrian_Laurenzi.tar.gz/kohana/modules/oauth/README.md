# OAuth for Kohana

An implementation of the [OAuth](http://oauth.net/) protocol.

*Does not provide server capabilities!*
