<?php defined('SYSPATH') OR die('No direct access allowed.');
/**
 * OAuth Credentials Request
 *
 * @package    Kohana/OAuth
 * @category   Request
 * @author     Kohana Team
 * @copyright  (c) 2010 Kohana Team
 * @license    http://kohanaframework.org/license
 * @since      3.0.7
 */
class Kohana_OAuth_Request_Credentials extends OAuth_Request{



} // End OAuth_Request_Credentials
