<?php defined('SYSPATH') or die('No direct script access.');

class OAuth extends Kohana_OAuth {  }
