<?php defined('SYSPATH') or die('No direct script access.');

abstract class OAuth_Provider extends Kohana_OAuth_Provider {  }
