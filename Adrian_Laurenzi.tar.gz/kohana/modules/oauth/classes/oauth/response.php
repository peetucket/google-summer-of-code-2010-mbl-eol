<?php defined('SYSPATH') or die('No direct script access.');

class OAuth_Response extends Kohana_OAuth_Response {  }
