<?php defined('SYSPATH') or die('No direct script access.');

abstract class OAuth_Signature extends Kohana_OAuth_Signature {  }
