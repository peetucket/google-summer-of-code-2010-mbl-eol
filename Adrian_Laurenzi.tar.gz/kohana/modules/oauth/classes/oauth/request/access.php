<?php defined('SYSPATH') or die('No direct script access.');

class OAuth_Request_Access extends Kohana_OAuth_Request_Access {  }
